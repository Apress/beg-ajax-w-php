<!-- theform.php -->
<div style="padding: 10px;">
	<div id="messagebox"></div>
	<form action="" method="post">
		Your Name<br />
		<input id="yourname" style="width: 150px; height: 16px;" type="text" value="" onkeypress="autocomplete(this.value, event)" /><br />
		Your Task<br />
		<textarea style="height: 80px;"></textarea><br />
		<input type="button" value="Submit" onclick="validateform (document.getElementById('yourname').value)" />
		<div align="right"><a href="javascript:closetask()">close</a></div>
	</form>
</div>